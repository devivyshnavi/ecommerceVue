export const MAIN_URL = "http://127.0.0.1:8000/api/";
export default MAIN_URL;